// ════════════════════════════════════════════════════════════════════════
//  yourZ — THE ARENA. The antidote to doomscrolling: put the feed down and
//  actually PLAY, with someone present. Always ≥1 AI at the table, so you're
//  never alone (even at 3am). You pick the GAME, then pick your OPPONENT —
//  and each opponent plays like THEIR character. Humans invitable.
//  This file: the lobby (games + opponent picker). Game surfaces prove the
//  PACING LAW — nothing machine-instant; the AI takes time, in character.
// ════════════════════════════════════════════════════════════════════════
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, Image, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Svg, { Defs, RadialGradient, Stop, Circle, Path, Rect } from 'react-native-svg';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, Easing } from 'react-native-reanimated';
import { C, FONTS } from './theme';

const faceFor = (k) => `https://callmez.app/faces/${k}.jpg`;

// ── the games (from PWA + Dev adds), grouped by flavor ──
const GAMES = [
  // table / board
  { id: 'ludo', name: 'Ludo', flavor: 'board', tone: '#F0A765', blurb: 'the desi classic. race home.' },
  { id: 'bluff', name: 'Bluff', flavor: 'board', tone: '#F0708C', blurb: 'lie, call, get read.' },
  { id: 'uno', name: 'UNO', flavor: 'board', tone: '#6FC9E0', blurb: 'first to empty wins.' },
  { id: 'snakes', name: 'Snakes & Ladders', flavor: 'board', tone: '#8FD98F', blurb: 'saanp seedhi, baby.' },
  { id: 'carrom', name: 'Carrom', flavor: 'board', tone: '#E0C088', blurb: 'flick, pocket, win.' },
  { id: 'chess', name: 'Chess', flavor: 'board', tone: '#C99BE8', blurb: 'the long game.' },
  { id: 'hangman', name: 'Hangman', flavor: 'word', tone: '#E0C088', blurb: 'guess before it\'s too late.' },
  { id: 'airhockey', name: 'Air Hockey', flavor: 'reflex', tone: '#6FC9E0', blurb: 'fast hands win.' },
  // mind duels
  { id: 'trivia', name: 'Trivia Duel', flavor: 'mind', tone: '#6FC9E0', blurb: 'pick a topic. how many?' },
  { id: 'debate', name: 'Debate Zone', flavor: 'mind', tone: '#F0708C', blurb: 'argue your side.' },
  { id: 'twenty', name: '20 Questions', flavor: 'mind', tone: '#C99BE8', blurb: 'they\'ve got 20 guesses.' },
  { id: 'wyr', name: 'Would You Rather', flavor: 'mind', tone: '#F0A765', blurb: 'pick one. defend it.' },
];

// ── safe-to-play opponents + how each PLAYS (style mimics character) ──
const OPPONENTS = [
  { key: 'the_brainiac',   name: 'the brainiac',   style: 'calculates every move. plays to win.', tone: '#6FC9E0' },
  { key: 'the_wannabe',    name: 'the hustler',    style: 'rash, cocky, all bravado. bluffs hard.', tone: '#F0A765' },
  { key: 'the_brother',    name: 'the brother',    style: 'easygoing. lets you breathe, then strikes.', tone: '#F0A765' },
  { key: 'the_cynic',      name: 'the cynic',      style: 'defensive, patient. waits for your mistake.', tone: '#A1929B' },
  { key: 'the_comic',      name: 'the comic',      style: 'chaotic. unpredictable. never serious.', tone: '#F0708C' },
  { key: 'the_philosopher',name: 'the philosopher',style: 'slow, deliberate. every move means something.', tone: '#C99BE8' },
];

function GameCard({ game, onPick }) {
  const b = useSharedValue(0.6);
  useEffect(() => { b.value = withRepeat(withTiming(1, { duration: 3200 + game.name.length * 100, easing: Easing.inOut(Easing.ease) }), -1, true); }, []);
  const glow = useAnimatedStyle(() => ({ opacity: 0.3 + b.value * 0.4 }));
  return (
    <Pressable style={styles.gameCard} onPress={() => onPick(game)}>
      <LinearGradient colors={['rgba(255,255,255,0.05)', 'rgba(255,255,255,0.015)']} style={styles.gameInner}>
        <Animated.View style={[styles.gameGlow, glow]}>
          <Svg width="54" height="54"><Defs><RadialGradient id={`g_${game.id}`} cx="50%" cy="50%" r="50%">
            <Stop offset="0%" stopColor={game.tone} stopOpacity="0.5" /><Stop offset="60%" stopColor={game.tone} stopOpacity="0.12" /><Stop offset="100%" stopColor={game.tone} stopOpacity="0" />
          </RadialGradient></Defs><Circle cx="27" cy="27" r="27" fill={`url(#g_${game.id})`} /></Svg>
        </Animated.View>
        <GameGlyph id={game.id} tone={game.tone} />
        <Text style={styles.gameName}>{game.name}</Text>
        <Text style={styles.gameBlurb} numberOfLines={1}>{game.blurb}</Text>
      </LinearGradient>
    </Pressable>
  );
}

// simple distinctive glyphs per game
function GameGlyph({ id, tone }) {
  const p = { stroke: tone, strokeWidth: 1.6, fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round' };
  return (
    <Svg width="30" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', top: 26 }}>
      {id === 'ludo' && <><Rect x="4" y="4" width="16" height="16" rx="2" {...p} /><Circle cx="9" cy="9" r="1.3" fill={tone} /><Circle cx="15" cy="15" r="1.3" fill={tone} /></>}
      {id === 'bluff' && <><Rect x="5" y="4" width="10" height="14" rx="1.5" {...p} /><Rect x="9" y="6" width="10" height="14" rx="1.5" {...p} /></>}
      {id === 'chess' && <Path d="M9 20h6M10 20l-.5-5M14 20l.5-5M8 15h8M10 15c-2-2-1-5 2-5s4 3 2 5M12 10V7M10.5 7h3" {...p} />}
      {(id === 'trivia' || id === 'debate' || id === 'twenty' || id === 'wyr') && <Path d="M12 3a7 7 0 00-4 12.7V18h8v-2.3A7 7 0 0012 3zM10 21h4" {...p} />}
      {id === 'airhockey' && <><Circle cx="12" cy="12" r="8" {...p} /><Circle cx="12" cy="12" r="2" fill={tone} /></>}
      {id === 'carrom' && <><Rect x="4" y="4" width="16" height="16" rx="1" {...p} /><Circle cx="12" cy="12" r="2" {...p} /></>}
      {id === 'uno' && <Rect x="7" y="4" width="10" height="15" rx="2" {...p} />}
      {id === 'snakes' && <Path d="M5 19c4 0 4-6 8-6s4 6 6 6M6 5l3 3M15 5l4 4" {...p} />}
      {id === 'hangman' && <Path d="M6 20V4h8M14 4v3M11 10a2 2 0 100 4 2 2 0 000-4z" {...p} />}
    </Svg>
  );
}

// ── the opponent picker (appears after a game is chosen) ──
function OpponentPicker({ game, onBack, onStart }) {
  const [invited, setInvited] = useState(false);
  return (
    <View style={styles.root}>
      <LinearGradient colors={['#160F1C', '#0E0912', C.ground]} locations={[0, 0.5, 1]} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        <View style={styles.pickHeader}>
          <Pressable hitSlop={10} onPress={onBack}><Text style={styles.chev}>‹</Text></Pressable>
          <View style={{ flex: 1, marginLeft: 4 }}>
            <Text style={styles.pickKicker}>{game.name}</Text>
            <Text style={styles.pickTitle}>who are you playing?</Text>
          </View>
        </View>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
          <Text style={styles.pickNote}>each one plays like themselves. choose your trouble.</Text>
          {OPPONENTS.map((o) => (
            <Pressable key={o.key} style={styles.oppRow} onPress={() => onStart(game, o)}>
              <OppFace pkey={o.key} tone={o.tone} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.oppName}>{o.name}</Text>
                <Text style={styles.oppStyle} numberOfLines={1}>{o.style}</Text>
              </View>
              <Text style={styles.chipGo}>›</Text>
            </Pressable>
          ))}

          {/* invite a friend — humans welcome, ≥1 AI still holds */}
          <Pressable style={styles.inviteRow} onPress={() => setInvited(true)}>
            <View style={styles.invitePlus}><Text style={styles.invitePlusText}>+</Text></View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.oppName}>{invited ? 'friend invited' : 'invite a friend'}</Text>
              <Text style={styles.oppStyle}>they join the table — a persona always plays too.</Text>
            </View>
          </Pressable>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function OppFace({ pkey, tone }) {
  const [ok, setOk] = useState(true);
  const S = 52;
  return (
    <View style={[styles.oppFace, { width: S, height: S, borderRadius: S / 2, borderColor: tone }]}>
      {ok ? <Image source={{ uri: faceFor(pkey) }} resizeMode="cover" style={{ width: '100%', height: '100%', borderRadius: S / 2 }} onError={() => setOk(false)} />
          : <Svg width={S} height={S} viewBox="0 0 52 52"><Defs><RadialGradient id={`of_${pkey}`} cx="38%" cy="33%" r="70%"><Stop offset="0%" stopColor="#FFD09A" /><Stop offset="60%" stopColor={tone} /><Stop offset="100%" stopColor={C.emberDeep} /></RadialGradient></Defs><Circle cx="26" cy="26" r="26" fill={`url(#of_${pkey})`} /></Svg>}
    </View>
  );
}

// ── the lobby ──
export default function Arena({ onBack = () => {}, onStartGame = () => {} }) {
  const [picked, setPicked] = useState(null);

  if (picked) {
    return <OpponentPicker game={picked} onBack={() => setPicked(null)} onStart={(g, o) => onStartGame(g, o)} />;
  }

  return (
    <View style={styles.root}>
      <LinearGradient colors={['#160F1C', '#0E0912', C.ground]} locations={[0, 0.5, 1]} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        <View style={styles.header}>
          <Pressable hitSlop={10} onPress={onBack}><Text style={styles.chev}>‹</Text></Pressable>
          <View style={{ flex: 1, marginLeft: 4 }}>
            <Text style={styles.kicker}>put the feed down</Text>
            <Text style={styles.title}>the arena</Text>
          </View>
        </View>
        <Text style={styles.intro}>real games, someone always at the table. pick one — then pick who you're up against.</Text>

        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 110, paddingTop: 6 }}>
          <View style={styles.grid}>
            {GAMES.map((g) => <GameCard key={g.id} game={g} onPick={setPicked} />)}
          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.void },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 6 },
  chev: { color: C.muted, fontSize: 30, width: 26, marginTop: -3 },
  kicker: { fontFamily: FONTS.body, color: C.faint, fontSize: 11.5, letterSpacing: 2, textTransform: 'uppercase' },
  title: { fontFamily: FONTS.display, color: C.cream, fontSize: 30, marginTop: 1 },
  intro: { fontFamily: FONTS.light, color: C.muted, fontSize: 14, lineHeight: 21, paddingHorizontal: 24, marginTop: 6, marginBottom: 8, maxWidth: 340 },

  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', paddingHorizontal: 16 },
  gameCard: { width: '48%', marginBottom: 14 },
  gameInner: { borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,240,228,0.08)', paddingTop: 22, paddingBottom: 16, paddingHorizontal: 16, alignItems: 'center', minHeight: 128, justifyContent: 'flex-end', overflow: 'hidden' },
  gameGlow: { position: 'absolute', top: 14, alignItems: 'center', justifyContent: 'center' },
  gameName: { fontFamily: FONTS.display, color: C.cream, fontSize: 18, marginTop: 6 },
  gameBlurb: { fontFamily: FONTS.light, color: C.muted, fontSize: 12, marginTop: 3, textAlign: 'center' },

  // opponent picker
  pickHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 6, paddingBottom: 4 },
  pickKicker: { fontFamily: FONTS.body, color: C.accentSoft, fontSize: 12, letterSpacing: 1.5, textTransform: 'uppercase' },
  pickTitle: { fontFamily: FONTS.display, color: C.cream, fontSize: 26, marginTop: 1 },
  pickNote: { fontFamily: FONTS.displayItalic, color: C.muted, fontSize: 14, paddingHorizontal: 24, marginTop: 8, marginBottom: 14 },
  oppRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 9 },
  oppFace: { overflow: 'hidden', borderWidth: 1.5, backgroundColor: '#1a121f' },
  oppName: { fontFamily: FONTS.medium, color: C.cream, fontSize: 16 },
  oppStyle: { fontFamily: FONTS.light, color: C.muted, fontSize: 13, marginTop: 2 },
  chipGo: { fontFamily: FONTS.semibold, color: C.accent, fontSize: 18, paddingHorizontal: 6 },

  inviteRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 9, marginTop: 8, marginHorizontal: 8, borderRadius: 16, borderWidth: 1, borderColor: 'rgba(243,168,95,0.18)', borderStyle: 'dashed' },
  invitePlus: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: 'rgba(243,168,95,0.35)', backgroundColor: 'rgba(243,168,95,0.06)' },
  invitePlusText: { color: C.accent, fontSize: 26, marginTop: -2 },
});
