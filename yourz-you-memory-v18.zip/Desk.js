// ════════════════════════════════════════════════════════════════════════
//  yourZ — THE FRONT DESK (home). Z as concierge: greets you, routes your
//  mood, and holds the two things Z manages FOR you — Letters (Z writes back)
//  and You (your profile/settings). The first thing you see: arriving
//  somewhere warm where Z is already waiting.
// ════════════════════════════════════════════════════════════════════════
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, Image, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Svg, { Defs, RadialGradient, Stop, Circle, Path, Ellipse } from 'react-native-svg';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, Easing } from 'react-native-reanimated';
import { C, FONTS } from './theme';

// the concierge presence — a soft warm ember greeting you
function DeskPresence() {
  const b = useSharedValue(0.7);
  useEffect(() => { b.value = withRepeat(withTiming(1, { duration: 4000, easing: Easing.inOut(Easing.ease) }), -1, true); }, []);
  const orb = useAnimatedStyle(() => ({ transform: [{ scale: 0.96 + b.value * 0.08 }] }));
  const halo = useAnimatedStyle(() => ({ opacity: 0.4 + b.value * 0.4 }));
  return (
    <View style={{ width: 90, height: 90, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View style={[StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center' }, halo]}>
        <Svg width="90" height="90"><Defs><RadialGradient id="deskHalo" cx="50%" cy="50%" r="50%">
          <Stop offset="0%" stopColor={C.emberHot} stopOpacity="0.5" /><Stop offset="55%" stopColor={C.ember} stopOpacity="0.14" /><Stop offset="100%" stopColor={C.ember} stopOpacity="0" />
        </RadialGradient></Defs><Circle cx="45" cy="45" r="45" fill="url(#deskHalo)" /></Svg>
      </Animated.View>
      <Animated.View style={orb}>
        <Svg width="60" height="60" viewBox="0 0 60 60"><Defs><RadialGradient id="deskOrb" cx="38%" cy="33%" r="70%">
          <Stop offset="0%" stopColor="#FFE6C4" /><Stop offset="45%" stopColor={C.ember} /><Stop offset="100%" stopColor={C.emberDeep} />
        </RadialGradient></Defs><Circle cx="30" cy="30" r="21" fill="url(#deskOrb)" /></Svg>
      </Animated.View>
    </View>
  );
}

// mood-routing chips
const MOODS = ['heavy day', 'need a laugh', 'want to think', 'just talk', 'celebrate'];

// letters — Z writes to you (daily anecdotes + weekly letters)
const LETTERS = [
  { id: 'w1', kind: 'weekly', date: 'this week', unread: true,
    body: "you carried a lot this week — three hard conversations, and you didn't flinch from any of them. i noticed you kept saying 'it's fine' when it wasn't. it doesn't have to be fine. but you showed up anyway, and that's the part worth remembering." },
  { id: 'd1', kind: 'daily', date: 'tuesday', unread: false,
    body: "you laughed today — really laughed, with the comic. i'd forgotten what that sounds like from you. more of that." },
];

function Letter({ letter, onOpen }) {
  const weekly = letter.kind === 'weekly';
  return (
    <Pressable style={[styles.letter, weekly && styles.letterWeekly]} onPress={() => onOpen(letter)}>
      <View style={styles.letterTop}>
        <Text style={styles.letterTag}>{weekly ? 'a letter' : 'a note'} · {letter.date}</Text>
        {letter.unread && <View style={styles.unread} />}
      </View>
      <Text style={styles.letterBody} numberOfLines={weekly ? 4 : 2}>{letter.body}</Text>
    </Pressable>
  );
}

export default function Desk({ onRoute = () => {}, onOpenYou = () => {}, onOpenLetter = () => {} }) {
  const hour = new Date().getHours();
  const greeting = hour < 5 ? 'still up' : hour < 12 ? 'good morning' : hour < 17 ? 'good afternoon' : hour < 22 ? 'good evening' : 'late night';

  return (
    <View style={styles.root}>
      <LinearGradient colors={['#1A1020', '#0E0912', C.ground]} locations={[0, 0.5, 1]} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 110 }}>
          {/* your profile, quiet, top-right */}
          <View style={styles.topRow}>
            <Pressable onPress={onOpenYou} style={styles.youChip}>
              <View style={styles.youAvatar}><Text style={styles.youInitial}>D</Text></View>
            </Pressable>
          </View>

          {/* Z greets you */}
          <View style={styles.greetWrap}>
            <DeskPresence />
            <Text style={styles.greeting}>{greeting}.</Text>
            <Text style={styles.deskSub}>i've got your list — and i know which room can help with whatever's next.</Text>
          </View>

          {/* mood routing */}
          <Text style={styles.sectionLabel}>what are you in the mood for?</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, gap: 10 }}>
            {MOODS.map((m) => (
              <Pressable key={m} style={styles.moodChip} onPress={() => onRoute(m)}>
                <Text style={styles.moodText}>{m}</Text>
              </Pressable>
            ))}
          </ScrollView>

          {/* letters — Z writes to you */}
          <View style={styles.lettersHead}>
            <Text style={styles.sectionLabel}>from Z</Text>
            <Text style={styles.lettersHint}>written while you were away</Text>
          </View>
          {LETTERS.map((l) => <Letter key={l.id} letter={l} onOpen={onOpenLetter} />)}
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.void },

  topRow: { flexDirection: 'row', justifyContent: 'flex-end', paddingHorizontal: 20, paddingTop: 8 },
  youChip: {},
  youAvatar: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(243,168,95,0.4)', backgroundColor: 'rgba(243,168,95,0.08)' },
  youInitial: { fontFamily: FONTS.display, color: C.accent, fontSize: 17 },

  greetWrap: { alignItems: 'center', paddingTop: 6, paddingBottom: 20, paddingHorizontal: 36 },
  greeting: { fontFamily: FONTS.display, color: C.cream, fontSize: 34, marginTop: 14 },
  deskSub: { fontFamily: FONTS.displayItalic, color: C.muted, fontSize: 14.5, textAlign: 'center', marginTop: 8, lineHeight: 21, maxWidth: 320 },

  sectionLabel: { fontFamily: FONTS.semibold, color: C.cream, fontSize: 14, letterSpacing: 0.4, paddingHorizontal: 24, marginBottom: 12, marginTop: 8 },

  moodChip: { paddingVertical: 10, paddingHorizontal: 18, borderRadius: 20, borderWidth: 1, borderColor: 'rgba(243,168,95,0.22)', backgroundColor: 'rgba(243,168,95,0.05)' },
  moodText: { fontFamily: FONTS.body, color: C.accentSoft, fontSize: 14 },

  lettersHead: { flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', paddingRight: 24, marginTop: 30 },
  lettersHint: { fontFamily: FONTS.displayItalic, color: C.faint, fontSize: 12.5 },
  letter: { marginHorizontal: 20, marginBottom: 12, padding: 18, borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,240,228,0.08)', backgroundColor: 'rgba(255,255,255,0.02)' },
  letterWeekly: { borderColor: 'rgba(243,168,95,0.20)', backgroundColor: 'rgba(243,168,95,0.03)' },
  letterTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  letterTag: { fontFamily: FONTS.body, color: C.faint, fontSize: 10.5, letterSpacing: 1.5, textTransform: 'uppercase' },
  unread: { width: 7, height: 7, borderRadius: 4, backgroundColor: C.ember, marginLeft: 8 },
  letterBody: { fontFamily: FONTS.displayItalic, color: '#E8DCCE', fontSize: 17, lineHeight: 26 },
});
